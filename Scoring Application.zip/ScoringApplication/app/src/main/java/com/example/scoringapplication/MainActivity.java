package com.example.scoringapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    int player1;
    int player2;
    int playerDiff;
    int gameScore1;
    int gameScore2;
    int switchCount;

    public void rightScoreChange(int a) {
        TextView rightTextScore = findViewById(R.id.rightTextScore);
        rightTextScore.setText("" + a);
    }

    public void leftScoreChange(int a) {
        TextView leftTextScore = findViewById(R.id.leftTextScore);
        leftTextScore.setText("" + a);
    }

    public void scoreChange() {
        TextView leftScore = (TextView)findViewById(R.id.leftScore);
        TextView rightScore = findViewById(R.id.rightScore);
        if (player1 > 11 && playerDiff ==2) {
            gameScore1 = gameScore1 + 1;
            leftScore.setText("" + gameScore1);
        }
        else if (player1 > 11 && player1 > player2) {
            gameScore1 = gameScore1 + 1;
            leftScore.setText("" + gameScore1);
        }
        else if (player2 > player1 && playerDiff > 2 && player2 > 11) {
            gameScore2 = gameScore2 + 1;
            rightScore.setText("" + gameScore2);

        }
    }

    public void switchGameScore() {
        TextView leftGameScore = findViewById(R.id.leftScore);
        TextView rightGameScore = findViewById(R.id.rightScore);
        int temp;
        if (switchCount % 2 == 0) {
            temp = gameScore1;
            gameScore1 = gameScore2;
            gameScore2 = temp;
        }
        else {
            temp = gameScore2;
            gameScore2 = gameScore1;
            gameScore1 = temp;
        }

        leftGameScore.setText("" + gameScore1);
        rightGameScore.setText("" + gameScore2);
    }

    public void scoreReset() {
        TextView leftScore = findViewById(R.id.leftTextScore);
        TextView rightScore = findViewById(R.id.rightTextScore);
        player1 = 0;
        player2= 0;

        leftScore.setText("" + player1);
        rightScore.setText("" + player2);
    }

    public void hardReset() {
        TextView leftScore = findViewById(R.id.leftTextScore);
        TextView rightScore = findViewById(R.id.rightTextScore);
        TextView leftGameScore = findViewById(R.id.leftScore);
        TextView rightGameScore = findViewById(R.id.rightScore);
        player1 = 0;
        player2= 0;
        gameScore1 = 0;
        gameScore2= 0;

        leftScore.setText("" + player1);
        rightScore.setText("" + player2);
        leftGameScore.setText("" + gameScore1);
        rightGameScore.setText("" + gameScore2);
    }


    public void twoPoints(int a, int b) {
        if (a > b) {
            playerDiff = (a-b);
        }
        else if (b > a) {
            playerDiff = (b-a);
        }
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startActivity(new Intent(MainActivity.this, server.class));

        final Button leftBut = (Button) findViewById(R.id.leftBut);
        leftBut.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                player1 = player1 + 1;
                leftScoreChange(player1);
                twoPoints(player1, player2);

                if (player1 > 11 && playerDiff > 2) {
                    scoreChange();
                    player1 = 0;
                    leftScoreChange(player1);
                    scoreReset();
                }

            }
        });
        final Button rightBut = (Button) findViewById(R.id.rightBut);
        rightBut.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                player2 = player2 + 1;
                rightScoreChange(player2);
                twoPoints(player1, player2);

                if (player2 > 11 && playerDiff > 2) {
                    scoreChange();
                    player2= 0;
                    rightScoreChange(player2);
                    scoreReset();
                }
            }
        });

        Button resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hardReset();
            }
        });

        Button switchButton = findViewById(R.id.switchButton);
        switchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchCount = switchCount + 1;
                switchGameScore();
            }
        });


            }

}
